﻿using System.Collections;
using System.Net;
using System.Security.Cryptography.X509Certificates;
// Martin Andres Morales Mazariegos 1217025 y Diego Alejandro Gualim Ramirez 1250025 //
namespace Juego
{
    public static class Globals
    {
        // A continuacion se declararan la mayoria de variables necesarias para el juego las cuales se pueden usar en todos los metodos de la clase// 
        public static string elegirPersonaje = "", usuario = "", personaje = "", elegirCamino = "", descripcionCamino = "", camino = "", enemigo1 = "", enemigo2 = "",  enemigoFinal = "", abrirCofre = "", huida = "si", enemigos1 = "", enemigos2 = "", enemigos3 = "", continuar = "si";
        
        public static int fase = 0, numeroPersonaje, numeroCamino, vidaPersonaje = 0, poderDeAtaquePersonaje = 0, escudo = 0, vidaEnemigo1 = 30, poderDeEnemigo1 = 20, vidaEnemigo2 = 50, poderDeEnemigo2 = 30, vidaJefeFinal = 70, poderJefeFinal1 = 50, cofre = 0, suerte = 0, enemigos = 3, enemigosDerrotados = 0;
        // El siguiente metodo es el Main donde se ejecutara el juego //
        public static void Main(string[] args)
        {
            string  nuevaPartida = "si";
            while(continuar == "si" && nuevaPartida == "si" && enemigos <= 3 && enemigos >= 1)
            {
                Console.WriteLine("THE GAME EL JUEGO. VERSION (1.0.0)");Console.WriteLine("");Console.WriteLine("PRESIONA [ENTER] PARA COMENZAR");Console.WriteLine("");
                Console.ReadKey();
                Console.Clear();

                Console.WriteLine("Bienvenido jugador, estas por comenzar una nueva aventura, elige un personaje:");
                // Aqui se elige personaje y se valida que sea un numero que este entre 1 y 3 //
                while(true)
                {
                    Console.WriteLine("===========================================================");
                    Console.WriteLine("||               ||                  ||                  ||");
                    Console.WriteLine("||    1. Mago    ||   2. Caballero   ||    3. Arquero    ||");
                    Console.WriteLine("||               ||                  ||                  ||");
                    Console.WriteLine("||  Vida: 100    ||     Vida: 70     ||     Vida: 85     ||");
                    Console.WriteLine("||               ||                  ||                  ||");
                    Console.WriteLine("||   Poder: 20   ||     Poder: 30    ||     Poder: 25    ||");
                    Console.WriteLine("||               ||                  ||                  ||");
                    Console.WriteLine("===========================================================");
                    Console.WriteLine("");
                    elegirPersonaje = Console.ReadLine();
                    if( int.TryParse(elegirPersonaje, out numeroPersonaje) && numeroPersonaje >= 1 && numeroPersonaje <=3 )
                    {
                        break;
                    }
                    else
                    {   Console.Clear();
                        Console.WriteLine("");Console.WriteLine("Dato invalido, ingresa un numero entero entre 1 y 3");
                    }
                }
                // Aqui se le asigna los valores al personaje segun lo elegido //
                if(numeroPersonaje == 1)
                {
                    personaje = "Mago"; vidaPersonaje = 100; poderDeAtaquePersonaje = 20;
                }
                else if(numeroPersonaje == 2)
                {
                    personaje = "Caballero"; vidaPersonaje = 70; poderDeAtaquePersonaje = 30;
                }
                else
                {
                     personaje = "Arquero"; vidaPersonaje = 85; poderDeAtaquePersonaje = 25;

                }
                Console.Clear();
                // Aqui se elige un nombre de usuario para el juego //
                Console.WriteLine("");Console.WriteLine("Excelente eleccion, cual es tu nombre aventurero?");Console.WriteLine("");
                usuario = Console.ReadLine();
                Console.Clear();
                // Aqui se elige un camino de los 3 que hay yy se valida que sea un numero y que este entre 1 y 3 //
                while(true)
                {
                    Console.WriteLine("");Console.WriteLine("Ahora elige un camino para tu aventura.");Console.WriteLine("");Console.WriteLine("1. Bosque Oscuro");Console.WriteLine("2. Cueva Sombria");Console.WriteLine("3. Camino de Piedra");Console.WriteLine("");
                    elegirCamino = Console.ReadLine();
                    if( int.TryParse(elegirCamino, out numeroCamino) && numeroCamino >= 1 && numeroCamino <=3 )
                    {
                        break;
                    }
                    else
                    {   Console.Clear();
                        Console.WriteLine(""); Console.WriteLine("Dato invalido, ingresa un numero entero entre 1 y 3");
                    }
                }
                // Aqui se asigna los valores al camino segun el elegido //
                if(numeroCamino == 1)
                {
                    camino = "BOSQUE OSCURO"; descripcionCamino = "Se pueden hallar tesoros sorprendentes o caer en trampas."; suerte = 5; cofre = 7; enemigo1 = "Bandido"; enemigos1 = "bandidos"; enemigo2 = "Monstruo"; enemigos2 = "monstruos"; enemigoFinal = "Hechicero";
                }
                else if(numeroCamino == 2)
                {
                    camino = "CUEVA SOMBRÌA"; descripcionCamino = "Con posibilidad de encontrar enemigos sigilosos. En este mapa los enemigos golpean primero."; suerte = 5; cofre = 7; enemigo1 = "Duende"; enemigos1 = "duendes"; enemigo2 = "Araña Gigante"; enemigos2 = "arañas gigantes"; enemigoFinal = "Rey Duende";
                }
                else
                {
                    camino = "CAMINO DE PIEDRA"; descripcionCamino = "Menos peligroso, pero con escasos recursos. En este mapa, los cofres tienen un 25% de probabilidad de estar vacíos."; suerte = 4; cofre = 9; enemigo1 = "Zombie"; enemigos1 = "zombies"; enemigo2 = "Golem de Piedra"; enemigos2 = "golems de piedra"; enemigoFinal = "Mutante de Roca";  

                }
                // A continuacion se muestra el mapa y segun donde este la flecha es tu avance y se llama al metodo correspondiente segun lo que pase //
                // Empieza la fase 1 //
                Console.Clear();
                fase = 1;
                Globals.MostrarDatos();
                Globals.Camino();
                Console.WriteLine("");Console.WriteLine("PRESIONA [ENTER] AVANZAR");Console.WriteLine("");
                Console.ReadKey();
                
                // Empieza la fase 2 //
                Console.Clear();
                fase = 2;
                Globals.MostrarDatos();
                Globals.Camino();
                Globals.SuerteMapa();
                while(true)
                {
                    Console.WriteLine("");Console.WriteLine("PRESIONA [ENTER] AVANZAR");Console.WriteLine("");
                    Console.ReadKey();
                    
                    // Empieza la fase 3 //
                    Console.Clear();
                    fase = 3;
                    Globals.MostrarDatos();
                    Globals.Camino();
                    Console.WriteLine(usuario +" estas por cruzar una zona peligrosa...");
                    Console.WriteLine("Los " +enemigos1 +" te han emboscado!!!");
                    Random Enemigos = new Random();
                    int cantidadEnemigos = Enemigos.Next(1, 4);
                    int numeroeleccion;
                    // Aqui comienza el primer combate de 3 del mapa //
                    while(true)
                    {
                        Console.WriteLine("");
                        Globals.MostrarDatos();
                        Globals.MostrarDatosEnemigo1();
                        // Aqui si la vida del personaje es menor o igual a cero se da la opcion de reiniciar el combate con menos vida que la inicial //
                        if(vidaPersonaje <= 0)
                        {
                            Console.WriteLine("Has perdido ¿Deseas reiniciar si o no?");
                            continuar = Console.ReadLine();
                            continuar.Trim().ToLower();
                            // Si elige reiniciar el personaje comienza otra vez con 80 de vida y el enemigo vuelve a su vida inicial //
                            if(continuar.Contains("si"))
                            {
                                vidaPersonaje = 80;
                                vidaEnemigo1 = 30; 
                            }
                            // Si elige no reiniciar el juego finaliza por completo //
                            if(continuar.Contains("no"))
                            {
                                continuar = "no";
                                return;
                            }
                        }
                        // Aqui si la vida del enemigo es menor o igual a cero pero aun queda mas de uno sube el contador de enemigos derrotados, la vida del personaje sube 40, baja la cantidad de enemigos y se vuelve a restaurar la vida del enemigo a 30 //
                        else if(vidaEnemigo1 <= 0 && cantidadEnemigos >= 1)
                        {
                            Console.WriteLine("Has derrotado al enemigo pero eso no es todo aun vienen más!!!");
                            vidaEnemigo1 = 30;
                            cantidadEnemigos = cantidadEnemigos - 1;
                            enemigosDerrotados = enemigosDerrotados + 1;
                            vidaPersonaje = vidaPersonaje + 40;
                        }
                        // Aqui si la vida del enemigo es menor o igual a cero y ya no hay enemigos finaliza el combate, la vida del personaje sube 40 y la cantidad de enemigos derrotados sube 1 //
                        else if(vidaEnemigo1 <= 0 && cantidadEnemigos < 1)
                        {
                            Console.WriteLine("Has derrotado al enemigo!!!");
                            cantidadEnemigos = cantidadEnemigos - 1;
                            enemigosDerrotados = enemigosDerrotados + 1;
                            vidaPersonaje = vidaPersonaje + 40;
                            huida = "no";
                            break;
                        }
                        // Aqui se pregunta si el usuario desea atacar o huir en el combate y ademas se valida que sea un numero y este entre 1 o 2//
                        Console.WriteLine("¿Que deseas hacer?");Console.WriteLine("");Console.WriteLine("1. Atacar");Console.WriteLine("2. Huir");Console.WriteLine("");
                        string eleccion = Console.ReadLine();

                        while(true)
                        {
                            if(int.TryParse(eleccion, out numeroeleccion) && numeroeleccion >= 1 && numeroeleccion <= 3)
                            {      
                                break;
                            }
                            else
                            {
                                Console.WriteLine("Dato invalido.");Console.WriteLine("¿Que deseas hacer?");Console.WriteLine("");Console.WriteLine("1. Atacar");Console.WriteLine("2. Huir");Console.WriteLine("");
                                eleccion = Console.ReadLine();
                            }   
                        }
                        // Aqui si decide atacar, atacara primero del enemigo o el usuario segun el camino //
                        if(numeroeleccion == 1)
                        {
                            // Si el camino es el 1 o el 3 el usuario ataca primero y luego ataca el enemigo //
                            if(numeroCamino == 1 || numeroCamino == 3)
                            {
                                Random ataque = new Random();
                                int dataque = ataque.Next(1, poderDeAtaquePersonaje);
                                Console.WriteLine("");
                                Console.WriteLine(personaje +" ha atacado, el enemigo ha perdido -" +dataque);
                                vidaEnemigo1 = vidaEnemigo1 - dataque;
                                Random ataqueenemigo1 = new Random();
                                int dataqueenemigo1 = ataqueenemigo1.Next(1, poderDeEnemigo1);
                                Console.WriteLine("");
                                Console.WriteLine(enemigo1 +" ha atacado, has perdido -" +dataqueenemigo1);
                                vidaPersonaje = vidaPersonaje - dataqueenemigo1;
                            }
                            // Aqui si el camino es el 2 el enemigo ataca primero y luego el usuario //
                            else if (numeroCamino == 2)
                            {
                                Random ataqueenemigo1 = new Random();
                                int dataqueenemigo1 = ataqueenemigo1.Next(1, poderDeEnemigo1);
                                Console.WriteLine("");
                                Console.WriteLine(enemigo1 +" ha atacado, has perdido -" +dataqueenemigo1);
                                vidaPersonaje = vidaPersonaje - dataqueenemigo1;
                                Random ataque = new Random();
                                int dataque = ataque.Next(1, poderDeAtaquePersonaje);
                                Console.WriteLine("");
                                Console.WriteLine(personaje +" ha atacado, el enemigo ha perdido -" +dataque);
                                vidaEnemigo1 = vidaEnemigo1 - dataque;
                            }
                        }
                        // Aqui si elige huir se le preguntara si esta seguro //
                        if(numeroeleccion == 2)
                        {
                            Console.WriteLine("¿De verdad quieres huir? Perderas 10 de vida.");
                            continuar = Console.ReadLine();
                            continuar.Trim().ToLower();
                            // Si el usuario pone que si huira y perdera 10 de vida regresando a la fase anterior //
                            if(continuar.Contains("si"))
                            {
                                huida = "si";
                                vidaPersonaje = vidaPersonaje - 10;
                                break;
                            }
                            // Si el usuario elige que no huira el combate continuara donde se quedo //
                            if(continuar.Contains("no"))
                            {
                                huida = "no";
                            }
                        }
                        Console.WriteLine("");
                        Console.WriteLine("Presiona ENTER");
                        Console.ReadKey();
                        Console.Clear();
                    }
                    // Este if es por si decide huir regresar a la fase anterior //
                    if(huida == "si")
                    {
                        continue;
                    }
                    // Si lo anterior es falso entonces finalizara el combate //
                    break;   
                }
                // Aqui finaliza el combate, se obtiene un cofre por la victoria y se avanza a la siguiente fase //
                Console.WriteLine("FELICIDADES!!!! Has derrotado a los " +enemigos1);
                enemigos = enemigos - 1;
                // Aqui se da la opcion de abrir el cofre o no //
                Console.WriteLine("");Console.WriteLine("Has conseguido un cofre!!!");Console.WriteLine("");Console.WriteLine("¿Deseas abrirlo?");
                string siono = Console.ReadLine();
                siono.Trim().ToLower();
                if(siono.Contains("si"))
                {Globals.Cofres();}
                Console.WriteLine("");Console.WriteLine("PRESIONA [ENTER] AVANZAR");Console.WriteLine("");
                Console.ReadKey();
                
                // Empieza la fase 4 //
                Console.Clear();
                fase = 4;
                Globals.MostrarDatos();
                Globals.Camino();
                Globals.SuerteMapa();
                huida = "si";
                while(true)
                {
                    Console.WriteLine("");Console.WriteLine("PRESIONA [ENTER] AVANZAR");Console.WriteLine("");
                    Console.ReadKey();

                    // Empieza la fase 5 //
                    Console.Clear();
                    fase = 5;
                    Globals.MostrarDatos();
                    Globals.Camino();
                    Console.WriteLine("CUIDADO!!!!! " +usuario +", " +enemigos2 +".");
                    Console.WriteLine("Los " +enemigos2 +" iran a por ti!!!");
                    Random Enemigos = new Random();
                    int cantidadEnemigos = Enemigos.Next(1, 4);
                    int numeroeleccion = 0;
                    // Aqui comienza el segundo combate de 3 del mapa //
                    while(true)
                    {
                        Console.WriteLine("");
                        Globals.MostrarDatos();
                        Globals.MostrarDatosEnemigo2();
                        // Aqui si la vida del personaje es menor o igual a cero se da la opcion de reiniciar el combate con menos vida que la inicial //
                        if(vidaPersonaje <= 0)
                        {
                            Console.WriteLine("Has perdido ¿Deseas reiniciar si o no?");
                            continuar = Console.ReadLine();
                            continuar.Trim().ToLower();
                            // Si elige reiniciar el personaje comienza otra vez con 80 de vida y el enemigo vuelve a su vida inicial //
                            if(continuar.Contains("si"))
                            {
                                vidaPersonaje = 80;
                                vidaEnemigo2 = 50; 
                            }
                            // Si elige no reiniciar el juego finaliza por completo //
                            if(continuar.Contains("no"))
                            {
                                continuar = "no";
                                return;
                            }
                        }
                        // Aqui si la vida del enemigo es menor o igual a cero pero aun queda mas de uno sube el contador de enemigos derrotados, la vida del personaje sube 40, baja la cantidad de enemigos y se vuelve a restaurar la vida del enemigo a 50 //
                        else if(vidaEnemigo2 <= 0 && cantidadEnemigos >= 1)
                        {
                            Console.WriteLine("Has derrotado al enemigo pero eso no es todo aun vienen más!!!");
                            vidaEnemigo2 = 50;
                            cantidadEnemigos = cantidadEnemigos - 1;
                            enemigosDerrotados = enemigosDerrotados + 1;
                            vidaPersonaje = vidaPersonaje + 40;
                        }
                        // Aqui si la vida del enemigo es menor o igual a cero y ya no hay enemigos finaliza el combate, la vida del personaje sube 40 y la cantidad de enemigos derrotados sube 1 //
                        else if(vidaEnemigo1 <= 0 && cantidadEnemigos < 1)
                        {
                            Console.WriteLine("Has derrotado al enemigo!!!");
                            cantidadEnemigos = cantidadEnemigos - 1;
                            enemigosDerrotados = enemigosDerrotados + 1;
                            vidaPersonaje = vidaPersonaje + 40;
                            huida = "no";
                            break;
                        }
                        // Aqui se pregunta si el usuario desea atacar o huir en el combate y ademas se valida que sea un numero y este entre 1 o 2//
                        Console.WriteLine("¿Que deseas hacer?");Console.WriteLine("");Console.WriteLine("1. Atacar");Console.WriteLine("2. Huir");Console.WriteLine("");
                        string eleccion = Console.ReadLine(); 
                        while(true)
                        {
                            if(int.TryParse(eleccion, out numeroeleccion))
                            {
                                break;
                            }
                            else
                            {
                                Console.WriteLine("Dato invalido.");Console.WriteLine("¿Que deseas hacer?");Console.WriteLine("");Console.WriteLine("1. Atacar");Console.WriteLine("2. Huir");Console.WriteLine("");
                                eleccion = Console.ReadLine();
                            }
                        }
                        // Aqui si decide atacar, atacara primero del enemigo o el usuario segun el camino //
                        if(numeroeleccion == 1)
                        {
                            // Si el camino es el 1 o el 3 el usuario ataca primero y luego ataca el enemigo //
                            if(numeroCamino == 1 || numeroCamino == 3)
                            {
                                Random ataque = new Random();
                                int dataque = ataque.Next(1, poderDeAtaquePersonaje);
                                Console.WriteLine("");
                                Console.WriteLine(personaje +" ha atacado, el enemigo ha perdido -" +dataque);
                                vidaEnemigo2 = vidaEnemigo2 - dataque;
                                Random ataqueenemigo2 = new Random();
                                int dataqueenemigo2 = ataqueenemigo2.Next(1, poderDeEnemigo2);
                                Console.WriteLine("");
                                Console.WriteLine(enemigo2 +" ha atacado, has perdido -" +dataqueenemigo2);
                                vidaPersonaje = vidaPersonaje - dataqueenemigo2;
                            }
                            // Aqui si el camino es el 2 el enemigo ataca primero y luego el usuario //
                            else if (numeroCamino == 2)
                            {
                                Random ataqueenemigo2 = new Random();
                                int dataqueenemigo2 = ataqueenemigo2.Next(1, poderDeEnemigo2);
                                Console.WriteLine("");
                                Console.WriteLine(enemigo2 +" ha atacado, has perdido -" +dataqueenemigo2);
                                vidaPersonaje = vidaPersonaje - dataqueenemigo2;
                                Random ataque = new Random();
                                int dataque = ataque.Next(1, poderDeAtaquePersonaje);
                                Console.WriteLine("");
                                Console.WriteLine(personaje +" ha atacado, el enemigo ha perdido -" +dataque);
                                vidaEnemigo2 = vidaEnemigo2 - dataque;
                            }
                        }
                        // Aqui si elige huir se le preguntara si esta seguro //
                        if(numeroeleccion == 2)
                        {
                            Console.WriteLine("¿De verdad quieres huir? Perderas 10 de vida.");
                            continuar = Console.ReadLine();
                            continuar.Trim().ToLower();
                            // Si el usuario pone que si huira y perdera 10 de vida regresando a la fase anterior //
                            if(continuar.Contains("si"))
                            {
                                huida = "si";
                                vidaPersonaje = vidaPersonaje - 10;
                                break;
                            }
                            // Si el usuario elige que no huira el combate continuara donde se quedo //
                            if(continuar.Contains("no"))
                            {
                                huida = "no";
                            }
                        }
                        Console.WriteLine("");
                        Console.WriteLine("Presiona ENTER");
                        Console.ReadKey();
                        Console.Clear();
                    }
                    // Este if es por si decide huir regresar a la fase anterior //
                    if(huida == "si")
                    {
                        continue;
                    }
                    // Si lo anterior es falso entonces finalizara el combate //
                    break;
                }
                // Aqui finaliza el combate, se obtiene un cofre por la victoria y se avanza a la siguiente fase //
                Console.WriteLine("ENHORABUENA!!!! Has vencido a los " +enemigos2);
                enemigos = enemigos - 1;
                // Aqui se da la opcion de abrir el cofre o no //
                Console.WriteLine("");Console.WriteLine("Has conseguido un cofre!!!");Console.WriteLine("");Console.WriteLine("¿Deseas abrirlo?");
                siono = Console.ReadLine();
                siono.Trim().ToLower();
                if(siono.Contains("si"))
                {Globals.Cofres();}
                Console.WriteLine("");Console.WriteLine("PRESIONA [ENTER] AVANZAR");Console.WriteLine("");
                Console.ReadKey();

                // Empieza la fase 6 //
                Console.Clear();
                fase = 6;
                Globals.MostrarDatos();
                Globals.Camino();
                Globals.SuerteMapa();
                huida = "si";
                while(true)
                {
                    int numeroeleccion = 0;
                    Console.WriteLine("");Console.WriteLine("PRESIONA [ENTER] AVANZAR");Console.WriteLine("");
                    Console.ReadKey();

                    // Empieza la fase 7 //
                    Console.Clear();
                    fase = 7;
                    Globals.MostrarDatos();
                    Globals.Camino();
                    Console.WriteLine(usuario +" el momento ha llegado.... Es tu momento de demostrar lo que tienes.");
                    Console.WriteLine("El jefe final ha llegado.... Ha llegado " +enemigoFinal +"!!!!!!");
                    // Aqui comienza el tercer combate de 3 del mapa //
                    while(true)
                    {
                        Console.WriteLine("");
                        Globals.MostrarDatos();
                        Globals.MostrarDatosEnemigo3();
                        // Aqui si la vida del personaje es menor o igual a cero se da la opcion de reiniciar el combate con menos vida que la inicial //
                        if(vidaPersonaje <= 0)
                        {
                            Console.WriteLine("Has perdido ¿Deseas reiniciar si o no?");
                            continuar = Console.ReadLine();
                            continuar.Trim().ToLower();
                            // Si elige reiniciar el personaje comienza otra vez con 100 de vida y el Jefe Final con 50 //
                            if(continuar.Contains("si"))
                            {
                                vidaPersonaje = 80;
                                vidaJefeFinal = 50; 
                            }
                            // Si elige no reiniciar el juego finalizara por completo //
                            if(continuar.Contains("no"))
                            {
                                continuar = "no";
                                return;
                            }
                        }
                        // Aqui si la vida del Jefe Final es menor o igual a cero el combate finaliza y los enemigos derrotados suben 1 //
                        if(vidaJefeFinal <= 0)
                        {
                            enemigosDerrotados = enemigosDerrotados + 1;
                            huida = "no";
                            break;
                        }
                        // Aqui se pregunta si el usuario desea atacar o huir en el combate y ademas se valida que sea un numero y este entre 1 o 2//
                        Console.WriteLine("¿Que deseas hacer?");Console.WriteLine("");Console.WriteLine("1. Atacar");Console.WriteLine("2. Huir");Console.WriteLine("");
                        string eleccion = Console.ReadLine(); 
                        while(true)
                        {
                            if(int.TryParse(eleccion, out numeroeleccion))
                            {
                                break;
                            }
                            else
                            {
                                Console.WriteLine("Dato invalido.");Console.WriteLine("¿Que deseas hacer?");Console.WriteLine("");Console.WriteLine("1. Atacar");Console.WriteLine("2. Huir");Console.WriteLine("");
                                eleccion = Console.ReadLine();
                            }
                        }
                        // Aqui si decide atacar, atacara primero del enemigo o el usuario segun el camino //
                        if(numeroeleccion == 1)
                        {
                            // Si el camino es el 1 o el 3 el usuario ataca primero y luego ataca el enemigo //
                            if(numeroCamino == 1 || numeroCamino == 3)
                            {
                                Random ataque = new Random();
                                int dataque = ataque.Next(1, poderDeAtaquePersonaje);
                                Console.WriteLine("");
                                Console.WriteLine(personaje +" ha atacado, el enemigo ha perdido -" +dataque);
                                vidaJefeFinal = vidaJefeFinal - dataque;
                                Random ataqueenemigo3 = new Random();
                                int dataqueenemigo3 = ataqueenemigo3.Next(1, poderJefeFinal1);
                                Console.WriteLine("");
                                Console.WriteLine(enemigoFinal +" ha atacado, has perdido -" +dataqueenemigo3);
                                vidaPersonaje = vidaPersonaje - dataqueenemigo3;
                            }
                            // Aqui si el camino es el 2 el enemigo ataca primero y luego el usuario //
                            else if (numeroCamino == 2)
                            {
                                Random ataqueenemigo3 = new Random();
                                int dataqueenemigo3 = ataqueenemigo3.Next(1, poderJefeFinal1);
                                Console.WriteLine("");
                                Console.WriteLine(enemigoFinal +" ha atacado, has perdido -" +dataqueenemigo3);
                                vidaPersonaje = vidaPersonaje - dataqueenemigo3;
                                Random ataque = new Random();
                                int dataque = ataque.Next(1, poderDeAtaquePersonaje);
                                Console.WriteLine("");
                                Console.WriteLine(personaje +" ha atacado, el enemigo ha perdido -" +dataque);
                                vidaJefeFinal = vidaJefeFinal - dataque;
                            }
                        }
                        // Aqui si elige huir se le preguntara si esta seguro //
                        if(numeroeleccion == 2)
                        {
                            Console.WriteLine("¿De verdad quieres huir? Perderas 10 de vida.");
                            continuar = Console.ReadLine();
                            continuar.Trim().ToLower();
                            // Si el usuario pone que si huira y perdera 10 de vida regresando a la fase anterior //
                            if(continuar.Contains("si"))
                            {
                                huida = "si";
                                vidaPersonaje = vidaPersonaje - 10;
                                continue;
                            }
                            // Si el usuario elige que no huira el combate continuara donde se quedo //
                            if(continuar.Contains("no"))
                            {
                                huida = "no";
                            }
                        }
                        Console.WriteLine("");
                        Console.WriteLine("Presiona ENTER");
                        Console.ReadKey();
                        Console.Clear();
                    }
                    // Este if es por si decide huir regresar a la fase anterior //
                    if(huida == "si")
                    {
                        continue;
                    }
                    // Si lo anterior es falso entonces finalizara el combate //
                    break;
                }
                Console.WriteLine("INCREIBLE!!!! Has vencido a " +enemigoFinal +" ERES UNA LEYENDA");
                enemigos = enemigos - 1;
                // Aqui finaliza el juego, se muestran tus estadisticas //
                Console.WriteLine("");Console.WriteLine("Estadisticas Finales: ");
                Globals.MostrarDatos();
                Console.WriteLine("");Console.WriteLine("Juego creado por:");Console.WriteLine("");Console.WriteLine("Martin Andres Morales Mazariegos - 1217025");Console.WriteLine("");Console.WriteLine("Diego Alejandro Gualim Ramirez - 1250025");Console.WriteLine("");
                // Aqui se valida la respuesta de si el usuario quiere inicar una nueva partida o no //
                while(true)
                {
                    // Aqui se da la opcion de iniciar una nueva partida //
                    Console.WriteLine("");Console.WriteLine("¿Quieres iniciar una nueva partida?");Console.WriteLine("");
                    nuevaPartida = Console.ReadLine();
                    nuevaPartida.Trim().ToLower();
                    // Si pone que si finzaliza esta parte para volver a repetirse todo desde cero //
                    if(nuevaPartida.Contains("si"))
                    {
                        break;
                    }
                    // Si pone que no todo finalizara //
                    else if(nuevaPartida.Contains("no"))
                    {
                        return;
                    }
                    // Si pone cualquier otra cosa el dato sera invalidado y se solicitara ingresarlo otra vez //
                    else
                    {
                        Console.WriteLine("");Console.WriteLine("Dato Invalido.");Console.WriteLine("");
                    }
                }
                // Si pone que si finzaliza esta parte para volver a repetirse todo desde cero //
                if(nuevaPartida.Contains("si"))
                {
                    nuevaPartida = "si";
                    continuar = "si";
                    enemigos = 3;
                    continue;
                }
            }   
        }
        // El siguiente metodo es al que se llama para mostrar en que fase de 7 del camino esta //
        public static void Camino()
        {
            Console.WriteLine(camino);
            Console.WriteLine("");
            Console.WriteLine(descripcionCamino);
            Console.WriteLine("");
            Console.WriteLine("");
            switch (fase)
            {
                case 1:
                Console.WriteLine("    ==");
                Console.WriteLine("    \\/");
                break;
                case 2:
                Console.WriteLine("                        ==");
                Console.WriteLine("                        \\/");
                break;
                case 3:
                Console.WriteLine("                                             ==");
                Console.WriteLine("                                             \\/");
                break;
                case 4:
                Console.WriteLine("                                                                  ==");
                Console.WriteLine("                                                                  \\/");
                break;
                case 5:
                Console.WriteLine("                                                                                       ==");
                Console.WriteLine("                                                                                       \\/");
                break;
                case 6:
                Console.WriteLine("                                                                                                             ==");
                Console.WriteLine("                                                                                                             \\/");
                break;
                case 7:
                Console.WriteLine("                                                                                                                                   ==");
                Console.WriteLine("                                                                                                                                   \\/");
                break;

            }                                       
            Console.WriteLine(" --------            --------             --------             --------             --------              --------              --------");
            Console.WriteLine("/        \\          /        \\           /        \\           /        \\           /        \\            /        \\            /        \\");
            Console.WriteLine("|        |=========|          |=========|          |=========|          |=========|          |==========|          |==========|          | ");
            Console.WriteLine("\\        /          \\        /           \\        /           \\        /           \\        /            \\        /            \\        /");
            Console.WriteLine(" --------            --------             --------             --------             --------              --------              --------");
            Console.WriteLine("  INICIO                                                                                                                          FIN");
        }
        // El siguiente metodo es para las fases del camino donde no hay un combate y pueden cosas diferentes desde caer en trampas hasta conseguir cofres segun el mapa y tu suerte //
        public static void SuerteMapa()
        {
            Random numero = new Random();
            int suerteMapa = numero.Next(1, suerte);
            if (suerteMapa == 1)
            {
                Console.WriteLine("Has encontrado un cofre, deseas abrirlo\n1.Si\n2.No");
                string siono =  Console.ReadLine();
                
                siono.Trim().ToLower();
                if(siono.Contains("si"))
                {Globals.Cofres();}
            }
            if (suerteMapa == 2)
            {
                vidaPersonaje=vidaPersonaje-5;
                Console.WriteLine("Tu personaje ha caido en una trampa, y tu vida se ha visto reducida: " +vidaPersonaje);
            }
            if (suerteMapa == 3)
            {
                Console.WriteLine("Tu aventura continua sin ningun percance o descubrimiento extraordinario.");
            }
            if (suerteMapa == 4)
            {
                Console.WriteLine("Tu aventura continua sin ningun percance o descubrimiento extraordinario.");
            }
        }
        // Este metodo es para lo que te puede salir dentro de un cofre y se llama si el usuario decide abrir el cofre cuando le aparece //
        public static void Cofres()
        {
            Random numero = new Random();
            int suerteCofre = numero.Next(1, cofre);
            if(suerteCofre == 1 || suerteCofre == 7)
            {
                Console.WriteLine("Has conseguido vida!!! Tu vida ha aumentado +10");
                vidaPersonaje = vidaPersonaje + 10;
            }
            if(suerteCofre == 2)
            {
                Console.WriteLine("Oh NO!!!! el cofre contenía un gas tóxico y lo has inhalado. Tu vida ha disminuido -5");
                vidaPersonaje = vidaPersonaje - 5;
            }
            if(suerteCofre == 3 || suerteCofre == 6)
            {
                Console.WriteLine("Enhorabuena, has encontrado escudo. Tu vida ha aumentado +10");
                escudo = escudo + 5;
            }
            if(suerteCofre == 4 || suerteCofre == 8)
            {
                Console.WriteLine("Al parecer has encontrado un orbe mágico misterioso y tu poder ha aumentado +5");
                poderDeAtaquePersonaje = poderDeAtaquePersonaje + 5;
            }
            if(suerteCofre == 5)
            {
                Console.WriteLine("El cofre esta vacio, no has encontrado nada....");
            }
        }
        // Este metodo es para mostrar los datos o estaditicas de tu personaje creado en el juego //
        public static void MostrarDatos()
        {
            Console.WriteLine("Usuario: " +usuario +" Personaje: " +personaje);
            Console.WriteLine("Vida: " +vidaPersonaje +" Enemigos Derrotados: " +enemigosDerrotados);
        }
        // Este metodo es para mostrar los datos o estaditicas del primer enemigo en el juego //
        public static void MostrarDatosEnemigo1()
        {
            Console.WriteLine("");Console.WriteLine("Enemigo: " +enemigo1 +" Vida: " +vidaEnemigo1);Console.WriteLine("");
        }
        // Este metodo es para mostrar los datos o estaditicas del segundo enemigo en el juego //
        public static void MostrarDatosEnemigo2()
        {
            Console.WriteLine("");Console.WriteLine("Enemigo: " +enemigo2 +" Vida: " +vidaEnemigo2);Console.WriteLine("");
        }
        // Este metodo es para mostrar los datos o estaditicas del tercer enemigo en el juego //
        public static void MostrarDatosEnemigo3()
        {
            Console.WriteLine("");Console.WriteLine("Enemigo: " +enemigoFinal +" Vida: " +vidaJefeFinal);Console.WriteLine("");
        }
    }
}