﻿public class Juego 
{
    // Este es el main donde se da la bienvenida, se muestran las reglas y se llama al metodo de todo el juego que contiene lo de las otras clases //
    public static void Main(string[] args)
    {
        Console.WriteLine("Bienvenido al juego NAVAL WARSHIPS\n\nPresiona [ENTER] para continuar\n");
        Console.ReadLine(); Console.Clear();
        Reglas();
        Combate juego = new Combate(); juego.CombateJuego();
    }
    // Este es un metodo donde se indican as reglas del juego //
    public static void Reglas()
    {
        Console.WriteLine("Reglas del juego: \n");
        Console.WriteLine("1. Cada jugador tiene un tablero de 6x6.");
        Console.WriteLine("2. Los jugadores recibiran una opcion al azar para colocar sus barcos en el tablero y si no les gusta pueden intentar otra vez.");
        Console.WriteLine("3. Los barcos pueden ser colocados horizontal o verticalmente.");
        Console.WriteLine("4. Los jugadores se turnan para disparar a las posiciones del tablero enemigo.");
        Console.WriteLine("5. Si un jugador acierta, se marca con una 'O', si falla, se marca con una 'X'.");
        Console.WriteLine("6. El juego termina cuando un jugador hunde todos los barcos del enemigo o cuando se acaben los 15 intentos de cada uno.");
        Console.WriteLine("7. Hay 3 barcos un submarino, una fragata y un destructor.");
        Console.WriteLine("8. El submarino ocupa 2 espacios, la fragata ocupa 3 espacios y el destructor ocupa 4 espacios.");
        Console.WriteLine("9. Por cada tiro acertado se sumara 1 punto.\n");
        Console.WriteLine("Presiona ENTER para continuar...");
        Console.ReadLine(); Console.Clear();
    }
}