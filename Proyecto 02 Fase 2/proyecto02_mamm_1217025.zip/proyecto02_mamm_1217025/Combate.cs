public class Combate : Tableros
{
    int puntajeUsuario1 = 0, puntajeUsuario2 = 0;
    string ataqueUsuario1 = "" , ataqueUsuario2 = "", opcion = "si", turno = "en progreso", rendirse = "no";
    int intentosUsuario1 = 0, intentosUsuario2 = 0;
    public void CombateJuego()
    {
        Usuarios();Console.Clear();
        PosicionBarcos1();
        // Aqui se valida si el jugador 1 desea cambiar la posicion de sus barcos o no //
        while (opcion == "si")
        {
            Console.Clear();
            TableroUsuario1();
            Console.WriteLine("Deseas cambiar la posición de los barcos? (si/no)\n");
            opcion = Console.ReadLine()!;
            opcion = opcion.Trim().ToLower();
            ValidarDatosSiNo();
            if (opcion == "si")
            {
                tablero1 = ["A1", "A2", "A3", "A4", "A5", "A6",
                                "B1", "B2", "B3", "B4", "B5", "B6",
                                "C1", "C2", "C3", "C4", "C5", "C6",
                                "D1", "D2", "D3", "D4", "D5", "D6",
                                "E1", "E2", "E3", "E4", "E5", "E6",
                                "F1", "F2", "F3", "F4", "F5", "F6"];
                PosicionBarcos1();
            }
        }
        PosicionBarcos2();opcion = "si";
        // Aqui se valida si el jugador 2 desea cambiar la posicion de sus barcos o no //
        while (opcion == "si")
        {
            Console.Clear();
            TableroUsuario2();
            Console.WriteLine("\n\nDeseas cambiar la posición de los barcos? (si/no)\n");
            opcion = Console.ReadLine()!;
            opcion = opcion.Trim().ToLower();
            ValidarDatosSiNo();
            if (opcion == "si")
            {
                tablero2 = ["A1", "A2", "A3", "A4", "A5", "A6",
                                "B1", "B2", "B3", "B4", "B5", "B6",
                                "C1", "C2", "C3", "C4", "C5", "C6",
                                "D1", "D2", "D3", "D4", "D5", "D6",
                                "E1", "E2", "E3", "E4", "E5", "E6",
                                "F1", "F2", "F3", "F4", "F5", "F6"];
                PosicionBarcos2();
            }
        }
        Console.Clear();Console.WriteLine("Presiona [ENTER] para comenzar ...\nComienza el juego!!!\n");
        Console.ReadLine();
        for (int intentos = 0; intentos < 15; intentos++)
        {
            TurnoJugador1();
            TurnoJugador2();
        }
        Ganador();
    }
    // Este metodo es todo lo que puede realizar el jugador 1 durante su turno //
    public void TurnoJugador1()
    {
        turno = "en progreso"; rendirse = "no";
        while (rendirse == "no")
        {
            while (turno == "en progreso")
            {
    // Aqui se valida si el jugador 1 desea 1. atacar o 2. rendirse 
                Console.Clear(); DatosUsuario1();
                Console.WriteLine("Que deseas hacer?\n1. Atacar\n2. Rendirse\n");
                opcion = Console.ReadLine()!;
                ValidarDatos1o2();
                if (opcion == "1")
                {
                    while (true)
                    {
                        Console.Clear();
                        DatosUsuario1();
                        Console.WriteLine(usuarios[0] + " , ingresa donde quieres hacer tu tiro (entre A1-F6):\n");
                        ataqueUsuario1 = Console.ReadLine()!;
    // Aqui se valida su tiro si es que decide atacar, se valida si ya ha realizado el msimo tiro anteriormente y si se encuentra en el tablero //
                        if (tableroValidacionTiros2.Contains(ataqueUsuario1))
                        {
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Tiro inválido. Intenta de nuevo:\nPresiona [ENTER] para intentarlo de nuevo. \n");
                            Console.ReadLine();
                        }
                    }
    // Aqui se valida si el tiro le dio a un barco o fallo //
                    for (int posicion = 0; posicion < 36; posicion++)
                    {
    // Aqui si acierta el tiro se sumara un punto al jugador 1 y cierta posicion de cada arreglo creado cambiara su valor a "O" //
                        if (posicionBarcos2.Contains(ataqueUsuario1) && tableroValidacionTiros2[posicion] == ataqueUsuario1)
                        {
                            Console.WriteLine("FELICIDADES, le has dado a un barco en " + ataqueUsuario1 + "\n");
                            tablero2[posicion] = "O";
                            tableroEnemigo2[posicion] = "O";
                            tableroValidacionTiros2[posicion] = "O";
                            puntajeUsuario1 += 1;
                            Console.WriteLine("Presiona ENTER para continuar\n");
                            Console.ReadLine();
                            intentosUsuario1 += 1;
                            rendirse = "si";
                            turno = "finalizado";
                            break;
                        }
    // Aqui si falla el tiro cierta posicion de cada arreglo creado cambiara su valor a "X" //
                        else if (tableroValidacionTiros2[posicion] == ataqueUsuario1)
                        {
                            Console.WriteLine("No le has dado a ningun barco, mas suerte a la proxima.\n");
                            tablero2[posicion] = "X";
                            tableroEnemigo2[posicion] = "X";
                            tableroValidacionTiros2[posicion] = "X";
                            Console.WriteLine("Presiona ENTER para continuar\n");
                            Console.ReadLine();
                            intentosUsuario1 += 1;
                            rendirse = "si";
                            turno = "finalizado";
                            break;
                        }
                    }
    // Aqui si el jugador destruye todos lo barcos llegaria a un puntaje de 9 puntos ganaria automaticamente //
                    if (puntajeUsuario1 == 9)
                    {
                        Console.WriteLine("Felicidades Jugador " + usuarios[0] + " has ganado con " + puntajeUsuario1 + " puntos.\n");
                        Environment.Exit(0);
                    }
                }
    // Aqui si el jugador eligio rendirse el juego finalizara y ganara el jugador 2 //
                if (puntajeUsuario2 == 9)
                {
                    Console.WriteLine("Felicidades Jugador " + usuarios[1] + " has ganado con " + puntajeUsuario2 + " puntos.\n");
                    Environment.Exit(0);
                }
                else if (opcion == "2")
                {
                    while (true)
                    {
                        Console.WriteLine("Estas seguro que quieres rendirte? si/no\n");
                        rendirse = Console.ReadLine()!;
                        rendirse.ToLower();
                        if (rendirse == "si" || rendirse == "no")
                        {
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Dato invalido.");
                        }
                    }
                    if (rendirse == "si")
                    {
                        Console.WriteLine("Has decidido rendirte. El jugador " + usuarios[1] + " ha ganado!\n");
                        Environment.Exit(0);
                    }
                    else
                    {
                        continue;
                    }
                }
            }
        }
    }
    // Este metodo es todo lo que puede realizar el jugador 2 durante su turno //
    public void TurnoJugador2()
    {
        turno = "en progreso"; rendirse = "no";
        while (rendirse == "no")
        {
            while (turno == "en progreso")
            {
    // Aqui se valida si el jugador 2 desea 1. atacar o 2. rendirse 
                Console.Clear();
                DatosUsuario2();
                Console.ResetColor();
                Console.WriteLine("Que deseas hacer?\n");
                Console.WriteLine("1. Atacar");
                Console.WriteLine("2. Rendirse\n");
                opcion = Console.ReadLine()!;
                ValidarDatos1o2();
                if (opcion == "1")
                {
                    while (true)
                    {
                        Console.Clear();
                        DatosUsuario2();
                        Console.WriteLine("\n\n" + usuarios[1] + " , ingresa donde quieres hacer tu tiro (entre A1-F6):\n");
                        ataqueUsuario2 = Console.ReadLine()!;
    // Aqui se valida su tiro si es que decide atacar, se valida si ya ha realizado el msimo tiro anteriormente y si se encuentra en el tablero //
                        if (tableroValidacionTiros1.Contains(ataqueUsuario2))
                        {
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Tiro inválido. Intenta de nuevo:\n");
                            Console.WriteLine("Presiona [ENTER] para intentarlo de nuevo. \n");
                            Console.ReadLine();
                        }
                    }
    // Aqui se valida si el tiro le dio a un barco o fallo //
                    for (int posicion = 0; posicion < 36; posicion++)
                    {
    // Aqui si acierta el tiro se sumara un punto al jugador 1 y cierta posicion de cada arreglo creado cambiara su valor a "O" //
                        if (posicionBarcos1.Contains(ataqueUsuario2) && tableroValidacionTiros1[posicion] == ataqueUsuario2)
                        {
                            Console.WriteLine("FELICIDADES, le has dado a un barco en " + ataqueUsuario2 + "\n");
                            tablero1[posicion] = "O";
                            tableroEnemigo1[posicion] = "O";
                            tableroValidacionTiros1[posicion] = "O";
                            puntajeUsuario2 += 1;
                            Console.WriteLine("Presiona ENTER para continuar\n");
                            Console.ReadLine();
                            intentosUsuario2 += 1;
                            rendirse = "si";
                            turno = "finalizado";
                            break;
                        }
    // Aqui si falla el tiro cierta posicion de cada arreglo creado cambiara su valor a "X" //
                        else if (tableroValidacionTiros1[posicion] == ataqueUsuario2)
                        {
                            Console.WriteLine("No le has dado a ningun barco, mas suerte a la proxima.\n");
                            tablero1[posicion] = "X";
                            tableroEnemigo1[posicion] = "X";
                            tableroValidacionTiros1[posicion] = "X";
                            Console.WriteLine("Presiona ENTER para continuar\n");
                            Console.ReadLine();
                            intentosUsuario2 += 1;
                            rendirse = "si";
                            turno = "finalizado";
                            break;
                        }
                    }
    // Aqui si el jugador destruye todos lo barcos llegaria a un puntaje de 9 puntos ganaria automaticamente //
                    if (puntajeUsuario2 == 9)
                    {
                        Console.WriteLine("Felicidades Jugador " + usuarios[1] + " has ganado con " + puntajeUsuario2 + " puntos.\n");
                        Environment.Exit(0);
                    }
                }
    // Aqui si el jugador eligio rendirse el juego finalizara y ganara el jugador 2 //
                else if (opcion == "2")
                {
                    while (true)
                    {
                        Console.WriteLine("Estas seguro que quieres rendirte? si/no\n");
                        rendirse = Console.ReadLine()!;
                        rendirse.ToLower();
                        if (rendirse == "si" || rendirse == "no")
                        {
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Dato invalido.");
                        }
                    }
                    if (rendirse == "si")
                    {
                        Console.WriteLine("Has decidido rendirte. El jugador " + usuarios[0] + " ha ganado!\n");
                        Environment.Exit(0);
                    }
                    else
                    {
                        continue;
                    }
                }
            }
        }
    }
    // Este metodo es para validar preguntas de si o no durante el juego //
    public void ValidarDatosSiNo()
    {
        while (true)
        {
            if (opcion == "si" || opcion == "no")
            {
                break;
            }
            else
            {
                Console.WriteLine("Opción inválida. Por favor, ingresa 'si' o 'no':");
                opcion = Console.ReadLine()!;
            }
        }
    }
    // Este metodo es para validar preguntas de 1 o 2 durante el juego //
    public void ValidarDatos1o2()
    {
        while (true)
        {
            if (opcion == "1" || opcion == "2")
            {
                break;
            }
            else
            {
                Console.WriteLine("Opción inválida. Por favor, ingresa '1' o '2':\n");
                opcion = Console.ReadLine()!;
            }
        }
    }
    // Este metodo es para mostrar los datos del jugador 1 como puntaje, nombre de usuario, tiros realizados y los tableros //
    public void DatosUsuario1()
    {
        Console.WriteLine("Usuario: " + usuarios[0] + "  Puntaje: " + puntajeUsuario1 + " Lanzamientos: " + intentosUsuario1 + "\n");
        TableroUsuario1(); TableroEnemigoUsuario1();
    }
    // Este metodo es para mostrar los datos del jugador 2 como puntaje, nombre de usuario, tiros realizados y los tableros //
    public void DatosUsuario2()
    {
        Console.WriteLine("Usuario: " + usuarios[1] + "  Puntaje: " + puntajeUsuario2 + " Lanzamientos: " + intentosUsuario2 + "\n");
        TableroUsuario2(); TableroEnemigoUsuario2();
    }
    // Este metodo es para validar quien ha sido el ganador luego de los 15 tiros, esto en caso de que nadie haya destruido todos los barcos //
    public void Ganador()
    {
        // Aqui si el jugador 1 tiene mayor puntaje que el jugador 2 ganara el jugador 1 // 
        if (puntajeUsuario1 > puntajeUsuario2)
        {
            Console.WriteLine("Felicidades Jugador " + usuarios[0] + " has ganado con " + puntajeUsuario1 + " puntos.\n");
        }
        // Aqui si el jugador 2 tiene mayor puntaje que el jugador 1 ganara el jugador 2 // 
        else if (puntajeUsuario2 > puntajeUsuario1)
        {
            Console.WriteLine("Felicidades Jugador " + usuarios[1] + " has ganado con " + puntajeUsuario2 + " puntos.\n");
        }
        // Aqui si los 2 puntajes resultan ser iguales sera un empate entre los jugadores 1 y 2 //
        else if (puntajeUsuario1 == puntajeUsuario2)
        {
            Console.WriteLine("Es un empate con " + puntajeUsuario1 + " puntos.\n");
        }
    }
}