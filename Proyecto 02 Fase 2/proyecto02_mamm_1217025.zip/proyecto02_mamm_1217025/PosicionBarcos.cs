public class PosicionBarco : Usuario
{
    public string[] posicionBarcos1 = new string[9];
    public string[] posicionBarcos2 = new string[9];
    public string[] tablero1 = {"A1", "A2", "A3", "A4", "A5", "A6",
                                "B1", "B2", "B3", "B4", "B5", "B6",
                                "C1", "C2", "C3", "C4", "C5", "C6",
                                "D1", "D2", "D3", "D4", "D5", "D6",
                                "E1", "E2", "E3", "E4", "E5", "E6",
                                "F1", "F2", "F3", "F4", "F5", "F6"};
    public string[] tablero2 = {"A1", "A2", "A3", "A4", "A5", "A6",
                                "B1", "B2", "B3", "B4", "B5", "B6",
                                "C1", "C2", "C3", "C4", "C5", "C6",
                                "D1", "D2", "D3", "D4", "D5", "D6",
                                "E1", "E2", "E3", "E4", "E5", "E6",
                                "F1", "F2", "F3", "F4", "F5", "F6"};
    public string[] tableroValidacionTiros1 = {"A1", "A2", "A3", "A4", "A5", "A6",
                                               "B1", "B2", "B3", "B4", "B5", "B6",
                                               "C1", "C2", "C3", "C4", "C5", "C6",
                                               "D1", "D2", "D3", "D4", "D5", "D6",
                                               "E1", "E2", "E3", "E4", "E5", "E6",
                                               "F1", "F2", "F3", "F4", "F5", "F6"};
    public string[] tableroValidacionTiros2 = {"A1", "A2", "A3", "A4", "A5", "A6",
                                               "B1", "B2", "B3", "B4", "B5", "B6",
                                               "C1", "C2", "C3", "C4", "C5", "C6",
                                               "D1", "D2", "D3", "D4", "D5", "D6",
                                               "E1", "E2", "E3", "E4", "E5", "E6",
                                               "F1", "F2", "F3", "F4", "F5", "F6"};
    // Este es un metodo para determinar la posicion de forma aleatoria de los barcos del jugador 1 en el juego // 
    public void PosicionBarcos1()
    {
        Random numeroAleatorio = new Random();
        int posicionBarco1 = numeroAleatorio.Next(1, 11);
        if (posicionBarco1 == 1)
        {
            posicionBarcos1 = ["A1", "A2", "A3", "B3", "C3", "C6", "D6", "E6", "F6"];
        }
        else if (posicionBarco1 == 2)
        {
            posicionBarcos1 = ["A3", "A4", "A5", "A6", "B1", "B2", "D3", "E3", "F3"];
        }
        else if (posicionBarco1 == 3)
        {
            posicionBarcos1 = ["A2", "A3", "D2", "E2", "F2", "C5", "D5", "E5", "F5"];
        }
        else if (posicionBarco1 == 4)
        {
            posicionBarcos1 = ["C2", "C3", "D1", "D2", "D3", "D4", "D6", "E6", "F6"];
        }
        else if (posicionBarco1 == 5)
        {
            posicionBarcos1 = ["D1", "D2", "A3", "B3", "C3", "D3", "D5", "E5", "F5"];
        }
        else if (posicionBarco1 == 6)
        {
            posicionBarcos1 = ["F1", "F2", "D3", "E3", "F3", "B2", "B3", "B4", "B5"];
        }
        else if (posicionBarco1 == 7)
        {
            posicionBarcos1 = ["D4", "D5", "B3", "B4", "B5", "B6", "A1", "B1", "C1"];
        }
        else if (posicionBarco1 == 8)
        {
            posicionBarcos1 = ["E2", "E3", "B6", "C6", "D6", "A1", "B1", "C1", "D1"];
        }
        else if (posicionBarco1 == 9)
        {
            posicionBarcos1 = ["E4", "E5", "B3", "B4", "B5", "B6", "C2", "D2", "E2"];
        }
        else if (posicionBarco1 == 10)
        {
            posicionBarcos1 = ["F2", "F3", "B2", "B3", "B4", "B5", "C5", "D5", "E5"];
        }
        foreach (string elemento in posicionBarcos1)
        {
            for (int i = 0; i < 36; i++)
            {
                if (elemento == tablero1[i])
                {
                    tablero1[i] = "O";
                }
            }
        }
    }
    // Este es un metodo para determinar la posicion de forma aleatoria de los barcos del jugador 2 en el juego // 
    public void PosicionBarcos2()
    {
        Random numeroAleatorio = new Random();
        Console.Clear();
        int posicionBarco2 = numeroAleatorio.Next(1, 11);
        if (posicionBarco2 == 1)
        {
            posicionBarcos2 = ["A1", "A2", "A3", "B3", "C3", "C6", "D6", "E6", "F6"];
        }
        else if (posicionBarco2 == 2)
        {
            posicionBarcos2 = ["A3", "A4", "A5", "A6", "B1", "B2", "D3", "E3", "F3"];
        }
        else if (posicionBarco2 == 3)
        {
            posicionBarcos2 = ["A2", "A3", "D2", "E2", "F2", "C5", "D5", "E5", "F5"];
        }
        else if (posicionBarco2 == 4)
        {
            posicionBarcos2 = ["C2", "C3", "D1", "D2", "D3", "D4", "D6", "E6", "F6"];
        }
        else if (posicionBarco2 == 5)
        {
            posicionBarcos2 = ["D1", "D2", "A3", "B3", "C3", "D3", "D5", "E5", "F5"];
        }
        else if (posicionBarco2 == 6)
        {
            posicionBarcos2 = ["F1", "F2", "D3", "E3", "F3", "B2", "B3", "B4", "B5"];
        }
        else if (posicionBarco2 == 7)
        {
            posicionBarcos2 = ["D4", "D5", "B3", "B4", "B5", "B6", "A1", "B1", "C1"];
        }
        else if (posicionBarco2 == 8)
        {
            posicionBarcos2 = ["E2", "E3", "B6", "C6", "D6", "A1", "B1", "C1", "D1"];
        }
        else if (posicionBarco2 == 9)
        {
            posicionBarcos2 = ["E4", "E5", "B3", "B4", "B5", "B6", "C2", "D2", "E2"];
        }
        else if (posicionBarco2 == 10)
        {
            posicionBarcos2 = ["F2", "F3", "B2", "B3", "B4", "B5", "C5", "D5", "E5"];
        }
        foreach (string elemento in posicionBarcos2)
        {
            for (int i = 0; i < 36; i++)
            {
                if (elemento == tablero2[i])
                {
                    tablero2[i] = "O";
                }
            }
        }
    }
}