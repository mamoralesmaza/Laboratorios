
public class Usuario
{
    public string [] usuarios = new string[2];
    // Este metodo es para que cada jugador se asigne un nombre de usuario para el juego // 
    public void Usuarios()
    {
        for (int i = 0; i < 2; i++)
        {
            while (true)
            {
                Console.WriteLine("Jugador " + (i + 1) + " ingresa el nombre que deseas:\n");
                usuarios[i] = Console.ReadLine()!;
                if (usuarios[i] == null  || usuarios[i] == "")
                {
                    Console.WriteLine("El nombre no puede estar vacío. Por favor, ingresa un nombre:\n");
                }
                else if (usuarios[i] != null)
                {
                    break;
                }
            }
        }
    }
}