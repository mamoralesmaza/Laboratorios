public class Tableros : PosicionBarco
{
    public string[] tableroEnemigo2 = {"~", "~", "~", "~", "~", "~",
                                       "~", "~", "~", "~", "~", "~",
                                       "~", "~", "~", "~", "~", "~",
                                       "~", "~", "~", "~", "~", "~",
                                       "~", "~", "~", "~", "~", "~",
                                       "~", "~", "~", "~", "~", "~"};
    public string[] tableroEnemigo1 = {"~", "~", "~", "~", "~", "~",
                                       "~", "~", "~", "~", "~", "~",
                                       "~", "~", "~", "~", "~", "~",
                                       "~", "~", "~", "~", "~", "~",
                                       "~", "~", "~", "~", "~", "~",
                                       "~", "~", "~", "~", "~", "~"};
    // Este metodo es para mostrar el tablero al jugador 1 el cual es el suyo //
    public void TableroUsuario1()
    {
        Console.WriteLine("Mi Tablero\n");
        Console.WriteLine("  1 2 3 4 5 6");
        Console.Write("A ");
        for (int coordenada = 0; coordenada < 36; coordenada++)
        {
            if (coordenada == 6)
            {
                Console.Write("\nB ");
            }
            if (coordenada == 12)
            {
                Console.Write("\nC ");
            }
            if (coordenada == 18)
            {
                Console.Write("\nD ");
            }
            if (coordenada == 24)
            {
                Console.Write("\nE ");
            }
            if (coordenada == 30)
            {
                Console.Write("\nF ");
            }
            // Aqui si no se ha hecho un tiro a cierta coodenada se mostrara el simbolo "~" en color azul //
            if (tablero1[coordenada] == "~")
            {
                Console.BackgroundColor = ConsoleColor.DarkBlue;
                Console.Write("  ");
                Console.BackgroundColor = ConsoleColor.Black;
            }
            // Aqui si se acerto un tiro a cierta coodenada se mostrara el simbolo "O" en color verde //
            else if (tablero1[coordenada] == "O")
            {
                Console.BackgroundColor = ConsoleColor.Green;
                Console.Write("X ");
                Console.BackgroundColor = ConsoleColor.Black;
            }
            // Aqui si se fallo un tiro a cierta coodenada se mostrara el simbolo "X" en color rojo //
            else if (tablero1[coordenada] == "X")
            {
                Console.BackgroundColor = ConsoleColor.Red;
                Console.Write("X ");
                Console.BackgroundColor = ConsoleColor.Black;
            }
            else
            {
                Console.BackgroundColor = ConsoleColor.DarkBlue;
                Console.Write("  ");
                Console.BackgroundColor = ConsoleColor.Black;
            }
        }
        Console.WriteLine("\n");
    }
    // Este metodo es para mostrar el tablero enemigo y a donde ha realizado los tiros el jugador 1 //
    public void TableroEnemigoUsuario1()
    {
        Console.WriteLine("Tablero Enemigo\n");
        Console.WriteLine("  1 2 3 4 5 6");
        Console.Write("A ");
        for (int coordenada = 0; coordenada < 36; coordenada++)
        {
            if (coordenada == 6)
            {
                Console.Write("\nB ");
            }
            if (coordenada == 12)
            {
                Console.Write("\nC ");
            }
            if (coordenada == 18)
            {
                Console.Write("\nD ");
            }
            if (coordenada == 24)
            {
                Console.Write("\nE ");
            }
            if (coordenada == 30)
            {
                Console.Write("\nF ");
            }
            // Aqui si no se ha hecho un tiro a cierta coodenada se mostrara el simbolo "~" en color azul //
            if (tableroEnemigo2[coordenada] == "~")
            {
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                Console.Write("~ ");
                Console.ResetColor();
            }
            // Aqui si se acerto un tiro a cierta coodenada se mostrara el simbolo "O" en color verde //
            else if (tableroEnemigo2[coordenada] == "O")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("O ");
                Console.ResetColor();
            }
            // Aqui si se fallo un tiro a cierta coodenada se mostrara el simbolo "X" en color rojo //
            else if (tableroEnemigo2[coordenada] == "X")
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("X ");
                Console.ResetColor();
            }
        }
        Console.WriteLine("\n");
    }
    // Este metodo es para mostrar el tablero al jugador 2 el cual es el suyo //
    public void TableroUsuario2()
    {
        Console.WriteLine("Mi Tablero\n");
        Console.WriteLine("  1 2 3 4 5 6");
        Console.Write("A ");
        for (int coordenada = 0; coordenada < 36; coordenada++)
        {
            if (coordenada == 6)
            {
                Console.Write("\nB ");
            }
            if (coordenada == 12)
            {
                Console.Write("\nC ");
            }
            if (coordenada == 18)
            {
                Console.Write("\nD ");
            }
            if (coordenada == 24)
            {
                Console.Write("\nE ");
            }
            if (coordenada == 30)
            {
                Console.Write("\nF ");
            }
            // Aqui si no se ha hecho un tiro a cierta coodenada se mostrara el simbolo "~" en color azul //
            if (tablero2[coordenada] == "~")
            {
                Console.BackgroundColor = ConsoleColor.DarkBlue;
                Console.Write("  ");
                Console.BackgroundColor = ConsoleColor.Black;
            }
            // Aqui si se acerto un tiro a cierta coodenada se mostrara el simbolo "O" en color verde //
            else if (tablero2[coordenada] == "O")
            {
                Console.BackgroundColor = ConsoleColor.Green;
                Console.Write("X ");
                Console.BackgroundColor = ConsoleColor.Black;
            }
            // Aqui si se fallo un tiro a cierta coodenada se mostrara el simbolo "X" en color rojo //
            else if (tablero2[coordenada] == "X")
            {
                Console.BackgroundColor = ConsoleColor.Red;
                Console.Write("X ");
                Console.BackgroundColor = ConsoleColor.Black;
            }
            else
            {
                Console.BackgroundColor = ConsoleColor.DarkBlue;
                Console.Write("  ");
                Console.BackgroundColor = ConsoleColor.Black;
            }
        }
    }
     // Este metodo es para mostrar el tablero enemigo y a donde ha realizado los tiros el jugador 2 //
    public void TableroEnemigoUsuario2()
    {
        Console.WriteLine(" \n\nTablero Enemigo\n");
        Console.WriteLine("  1 2 3 4 5 6");
        Console.Write("A ");
        for (int coordenada = 0; coordenada < 36; coordenada++)
        {
            if (coordenada == 6)
            {
                Console.Write("\nB ");
            }
            if (coordenada == 12)
            {
                Console.Write("\nC ");
            }
            if (coordenada == 18)
            {
                Console.Write("\nD ");
            }
            if (coordenada == 24)
            {
                Console.Write("\nE ");
            }
            if (coordenada == 30)
            {
                Console.Write("\nF ");
            }
            // Aqui si no se ha hecho un tiro a cierta coodenada se mostrara el simbolo "~" en color azul //
            if (tableroEnemigo1[coordenada] == "~")
            {
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                Console.Write("~ ");
                Console.ResetColor();
            }
            // Aqui si se acerto un tiro a cierta coodenada se mostrara el simbolo "O" en color verde //
            else if (tableroEnemigo1[coordenada] == "O")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("O ");
                Console.ResetColor();
            }
            // Aqui si se fallo un tiro a cierta coodenada se mostrara el simbolo "X" en color rojo //
            else if (tableroEnemigo1[coordenada] == "X")
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("X ");
                Console.ResetColor();
            }
        }
        Console.WriteLine("\n");
    }
}